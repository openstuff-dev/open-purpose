import * as i0 from "@angular/core";
import { InjectionToken, Signal, TemplateRef } from "@angular/core";
import { IconNode } from "@openstuff-dev/ui";
import * as i1 from "@angular/aria/tabs";
type Tone = 'neutral' | 'brand' | 'danger' | 'warning' | 'success' | 'info';
/** A short label such as a status or a count: `<span os-badge tone="success">Live</span>`. */
export declare class Badge {
  readonly tone: import("@angular/core").InputSignal<Tone>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Badge, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Badge, "[os-badge]", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A value in a list, such as a path or a tag. With `removable`, it gets a remove button named
 * "Remove <its text>".
 *
 * ```html
 * <span os-chip removable (removed)="drop(path)">{{ path }}</span>
 * ```
 */
export declare class Chip {
  readonly tone: import("@angular/core").InputSignal<Tone>;
  readonly removable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly removed: import("@angular/core").OutputEmitterRef<void>;
  protected readonly iconX: import("@openstuff-dev/ui").IconNode;
  protected readonly textId: string;
  protected readonly buttonId: string;
  static ɵfac: i0.ɵɵFactoryDeclaration<Chip, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Chip, "[os-chip]", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "removable": {
      "alias": "removable";
      "required": false;
      "isSignal": true;
    };
  }, {
    "removed": "removed";
  }, never, ["*"], true, never>;
}
/** A coloured dot before a status: `<span os-status-dot tone="danger">Failed</span>`. */
export declare class StatusDot {
  readonly tone: import("@angular/core").InputSignal<Tone>;
  /** Pulses gently, for something in progress. */
  readonly pulse: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<StatusDot, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<StatusDot, "[os-status-dot]", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "pulse": {
      "alias": "pulse";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
type ButtonVariant = 'primary' | 'default' | 'ghost' | 'danger' | 'link';
type ButtonSize = 'sm' | 'md';
/**
 * A native button or link styled as an OpenStuff button.
 *
 * ```html
 * <button os-button variant="primary" type="submit" [loading]="saving()">Save</button>
 * <a os-button variant="link" href="/docs">Docs</a>
 * ```
 */
export declare class Button {
  readonly variant: import("@angular/core").InputSignal<ButtonVariant>;
  readonly size: import("@angular/core").InputSignal<ButtonSize>;
  /** Shows a spinner and ignores clicks, but keeps focus (unlike `disabled`). */
  readonly loading: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<Button, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Button, "button[os-button], a[os-button]", never, {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "loading": {
      "alias": "loading";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * A square button with only an icon. `label` is required and becomes its accessible name.
 *
 * ```html
 * <button os-icon-button label="Close" (click)="close()"><os-icon [icon]="X" /></button>
 * ```
 */
export declare class IconButton extends Button {
  readonly label: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<IconButton, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<IconButton, "button[os-icon-button], a[os-icon-button]", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * A highlighted message in the page. Add `role="alert"` for an error the person must see now,
 * or `role="status"` for one that appears after an action.
 *
 * ```html
 * <os-callout tone="warning" title="Read-only">You can't edit this project.</os-callout>
 * ```
 */
export declare class Callout {
  readonly tone: import("@angular/core").InputSignal<Tone>;
  readonly title: import("@angular/core").InputSignal<string | undefined>;
  protected readonly icon: import("@angular/core").Signal<IconNode>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Callout, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Callout, "os-callout", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*", "[os-actions]"], true, never>;
}
/**
 * What a list or page shows when there's nothing in it yet, and what to do about it.
 *
 * ```html
 * <os-empty-state title="No proposals yet" [icon]="Inbox">
 *   When an agent suggests a rule, it shows up here.
 *   <button os-button os-actions variant="primary">Write one</button>
 * </os-empty-state>
 * ```
 */
export declare class EmptyState {
  readonly title: import("@angular/core").InputSignal<string>;
  readonly icon: import("@angular/core").InputSignal<IconNode | undefined>;
  /** The title's heading level, to fit the page's outline. */
  readonly level: import("@angular/core").InputSignalWithTransform<number, unknown>;
  /** Draws a dashed border, for an empty area inside a page. */
  readonly bordered: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<EmptyState, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<EmptyState, "os-empty-state", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "level": {
      "alias": "level";
      "required": false;
      "isSignal": true;
    };
    "bordered": {
      "alias": "bordered";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*", "[os-actions]"], true, never>;
}
/** A key or shortcut: `<kbd os-kbd>⌘K</kbd>`. */
export declare class Kbd {
  static ɵfac: i0.ɵɵFactoryDeclaration<Kbd, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Kbd, "kbd[os-kbd]", never, {}, {}, never, never, true, never>;
}
/**
 * A placeholder while content loads. It's hidden from screen readers: set `aria-busy="true"`
 * on the region that's loading.
 */
export declare class Skeleton {
  /** How many lines of text it stands in for. */
  readonly lines: import("@angular/core").InputSignalWithTransform<number, unknown>;
  readonly shape: import("@angular/core").InputSignal<"text" | "circle">;
  static ɵfac: i0.ɵɵFactoryDeclaration<Skeleton, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Skeleton, "os-skeleton", never, {
    "lines": {
      "alias": "lines";
      "required": false;
      "isSignal": true;
    };
    "shape": {
      "alias": "shape";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** What a control inside a Field or SettingRow reads to wire itself up. */
interface FieldContext {
  readonly controlId: string;
  /** The ids of the hint and error, for aria-describedby. */
  readonly describedBy: Signal<string | null>;
  readonly invalid: Signal<boolean>;
}
export declare const FIELD: InjectionToken<FieldContext>;
/**
 * A label, a control and an optional hint and error. The control gets the label's id,
 * aria-describedby and aria-invalid on its own.
 *
 * ```html
 * <os-field label="Name" hint="Shown to your team." [error]="nameError()">
 *   <input os-input [(ngModel)]="name" />
 * </os-field>
 * ```
 */
export declare class Field implements FieldContext {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly hint: import("@angular/core").InputSignal<string | undefined>;
  /** Shown under the control, and marks it invalid. */
  readonly error: import("@angular/core").InputSignal<string | null | undefined>;
  readonly controlId: string;
  protected readonly hintId: string;
  protected readonly errorId: string;
  protected readonly iconCircleAlert: import("@openstuff-dev/ui").IconNode;
  readonly invalid: Signal<boolean>;
  readonly describedBy: Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Field, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Field, "os-field", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "error": {
      "alias": "error";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/** Styles and wires up a text input, textarea or select inside a Field (or on its own). */
export declare class Control {
  protected readonly field: FieldContext | null;
  protected readonly tag: string;
  readonly size: import("@angular/core").InputSignal<"sm" | "md">;
  /** Marks the control invalid when it isn't in a Field. */
  readonly invalid: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly id: import("@angular/core").InputSignal<string>;
  protected readonly isInvalid: Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Control, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Control, "input[os-input], textarea[os-textarea], select[os-select]", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A checkbox, radio or switch with its label. The input keeps all its native behaviour.
 *
 * ```html
 * <label os-check><input type="checkbox" os-checkbox [(ngModel)]="reviews" /> Reviews</label>
 * <label os-check><input type="checkbox" os-switch [(ngModel)]="agentMode" /> Agent mode</label>
 * ```
 */
export declare class Check {
  static ɵfac: i0.ɵɵFactoryDeclaration<Check, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Check, "label[os-check]", never, {}, {}, never, never, true, never>;
}
export declare class Checkbox {
  static ɵfac: i0.ɵɵFactoryDeclaration<Checkbox, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Checkbox, "input[type=checkbox][os-checkbox]", never, {}, {}, never, never, true, never>;
}
export declare class Radio {
  static ɵfac: i0.ɵɵFactoryDeclaration<Radio, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Radio, "input[type=radio][os-radio]", never, {}, {}, never, never, true, never>;
}
/** A checkbox shown as an on/off switch (role="switch"). A SettingRow labels it. */
export declare class Switch {
  protected readonly field: FieldContext | null;
  readonly id: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Switch, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Switch, "input[type=checkbox][os-switch]", never, {
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** A group of checkboxes or radios with a legend: `<fieldset os-fieldset>`. */
export declare class Fieldset {
  static ɵfac: i0.ɵɵFactoryDeclaration<Fieldset, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Fieldset, "fieldset[os-fieldset]", never, {}, {}, never, never, true, never>;
}
/**
 * A Lucide icon. It's decorative: put the text that names it next to it, or `label` on the
 * button that holds it.
 *
 * ```ts
 * import { Search } from 'lucide';
 * ```
 * ```html
 * <svg os-icon [icon]="Search"></svg>
 * ```
 */
export declare class Icon {
  readonly icon: import("@angular/core").InputSignal<IconNode>;
  readonly size: import("@angular/core").InputSignal<"sm" | "md" | "lg">;
  /** Turns the icon around in right-to-left text, for arrows that point forward. */
  readonly flipInRtl: import("@angular/core").InputSignal<boolean>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<Icon, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Icon, "svg[os-icon]", never, {
    "icon": {
      "alias": "icon";
      "required": true;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "flipInRtl": {
      "alias": "flipInRtl";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
interface SegmentOption<T extends string = string> {
  value: T;
  label: string;
  disabled?: boolean;
}
/**
 * A row of options where one is picked, such as a view switch. It's native radios, so arrow
 * keys move between options and it works in a form.
 *
 * ```html
 * <os-segmented-control label="View" [options]="views" [(value)]="view" />
 * ```
 */
export declare class SegmentedControl<T extends string = string> {
  /** Names the group for screen readers. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly options: import("@angular/core").InputSignal<readonly SegmentOption<T>[]>;
  readonly value: import("@angular/core").ModelSignal<T | undefined>;
  readonly size: import("@angular/core").InputSignal<"sm" | "md">;
  /** The radios' form name. */
  readonly name: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SegmentedControl<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SegmentedControl<any>, "os-segmented-control", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": true;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, never, true, never>;
}
interface Command {
  id: string;
  label: string;
  /** Commands with the same group are listed together under it. */
  group?: string;
  /** Text at the end of the row, such as a shortcut. */
  hint?: string;
  /** Other words that find it. */
  keywords?: readonly string[];
  icon?: IconNode;
}
interface Group {
  name: string | undefined;
  id: string;
  commands: {
    command: Command;
    id: string;
  }[];
}
/** True when every word of the query starts a word of the text (or appears in it). */
export declare function matchesQuery(command: Command, query: string): boolean;
/**
 * Search and run commands from the keyboard. Open it from a shortcut such as Ctrl+K; type to
 * filter, arrow keys to move, Enter to run, Escape to close.
 *
 * ```html
 * <os-command-palette [(open)]="paletteOpen" [commands]="commands" (run)="go($event)" />
 * ```
 */
export declare class CommandPalette {
  readonly open: import("@angular/core").ModelSignal<boolean>;
  readonly commands: import("@angular/core").InputSignal<readonly Command[]>;
  /** Names the dialog and the search box. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  /** The command the person chose. The palette closes first. */
  readonly run: import("@angular/core").OutputEmitterRef<Command>;
  protected readonly iconSearch: IconNode;
  protected readonly listId: string;
  protected readonly query: import("@angular/core").WritableSignal<string>;
  protected readonly active: import("@angular/core").WritableSignal<Command | undefined>;
  private readonly prefix;
  protected readonly results: import("@angular/core").Signal<Command[]>;
  protected readonly groups: import("@angular/core").Signal<Group[]>;
  /** In display order, which is what the arrow keys follow. */
  private readonly ordered;
  protected readonly activeId: import("@angular/core").Signal<string | null>;
  protected onInput(value: string): void;
  protected onKeydown(event: KeyboardEvent): void;
  protected choose(command: Command | undefined): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<CommandPalette, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CommandPalette, "os-command-palette", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "commands": {
      "alias": "commands";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
    "run": "run";
  }, never, never, true, never>;
}
interface ConfirmOptions {
  title: string;
  message: string;
  /** The confirm button's text. Name the action: "Delete draft", not "OK". */
  confirmLabel: string;
  cancelLabel?: string;
  /** Makes the confirm button red, for something that can't be undone. */
  danger?: boolean;
}
/**
 * Asks the person to confirm an action in a small modal dialog.
 *
 * ```ts
 * if (await inject(ConfirmDialog).confirm({
 *   title: 'Delete draft?',
 *   message: "The draft and its comments are deleted. You can't undo this.",
 *   confirmLabel: 'Delete draft',
 *   danger: true,
 * })) remove();
 * ```
 */
export declare class ConfirmDialog {
  private readonly app;
  private readonly injector;
  /** Resolves to true when the person confirms, false when they cancel or press Escape. */
  confirm(options: ConfirmOptions): Promise<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmDialog, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
type ClosedBy = 'any' | 'closerequest' | 'none';
/** What Dialog and Drawer share: opening and closing a native <dialog> from `open`. */
export declare abstract class DialogBase {
  /** Two-way: set it to open the dialog; it turns false when the dialog closes. */
  readonly open: import("@angular/core").ModelSignal<boolean>;
  /**
   * What closes it besides its own buttons: `any` (Escape or a click outside, the default),
   * `closerequest` (Escape only) or `none`.
   */
  readonly closedby: import("@angular/core").InputSignal<ClosedBy>;
  /** Opens without a backdrop and leaves the page usable. */
  readonly nonModal: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly element: HTMLDialogElement;
  /** Set by DialogTitle, which names the dialog. */
  readonly titleId: import("@angular/core").WritableSignal<string | null>;
  constructor();
  close(returnValue?: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogBase, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DialogBase, never, never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "closedby": {
      "alias": "closedby";
      "required": false;
      "isSignal": true;
    };
    "nonModal": {
      "alias": "nonModal";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, never, never, true, never>;
}
/**
 * A modal dialog on a native <dialog>: focus moves in and back, Escape closes it, and the page
 * behind it is inert. Name it with a DialogTitle.
 *
 * ```html
 * <dialog os-dialog [(open)]="editing">
 *   <header os-dialog-header><h2 os-dialog-title>Rename project</h2></header>
 *   <div os-dialog-body>…</div>
 *   <footer os-dialog-footer>
 *     <button os-button os-dialog-close>Cancel</button>
 *     <button os-button variant="primary" (click)="save()">Save</button>
 *   </footer>
 * </dialog>
 * ```
 */
export declare class Dialog extends DialogBase {
  readonly size: import("@angular/core").InputSignal<"sm" | "md" | "lg">;
  static ɵfac: i0.ɵɵFactoryDeclaration<Dialog, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Dialog, "dialog[os-dialog]", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * A panel that slides in from the side, for details or a form next to a list. Same parts and
 * behaviour as Dialog.
 *
 * ```html
 * <dialog os-drawer [(open)]="showFinding">…</dialog>
 * ```
 */
export declare class Drawer extends DialogBase {
  readonly side: import("@angular/core").InputSignal<"start" | "end">;
  readonly size: import("@angular/core").InputSignal<"md" | "lg">;
  static ɵfac: i0.ɵɵFactoryDeclaration<Drawer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Drawer, "dialog[os-drawer]", never, {
    "side": {
      "alias": "side";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export declare class DialogHeader {
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogHeader, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DialogHeader, "[os-dialog-header]", never, {}, {}, never, never, true, never>;
}
export declare class DialogBody {
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogBody, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DialogBody, "[os-dialog-body]", never, {}, {}, never, never, true, never>;
}
export declare class DialogFooter {
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogFooter, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DialogFooter, "[os-dialog-footer]", never, {}, {}, never, never, true, never>;
}
/** The dialog's heading. It becomes the dialog's accessible name. */
export declare class DialogTitle {
  readonly id: string;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogTitle, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DialogTitle, "[os-dialog-title]", never, {}, {}, never, never, true, never>;
}
/** Closes the dialog or drawer it's in: `<button os-button os-dialog-close>Cancel</button>`. */
export declare class DialogClose {
  protected readonly dialog: DialogBase;
  /** The dialog's returnValue after closing. */
  readonly returnValue: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogClose, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DialogClose, "button[os-dialog-close]", never, {
    "returnValue": {
      "alias": "os-dialog-close";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
type Placement = 'bottom' | 'top' | 'start' | 'end';
/** What Popover and Menu share: a native popover with an id, opened next to its trigger. */
export declare abstract class PopoverBase {
  readonly placement: import("@angular/core").InputSignal<Placement>;
  readonly element: HTMLElement;
  readonly id: string;
  readonly isOpen: import("@angular/core").WritableSignal<boolean>;
  show(source?: HTMLElement): void;
  hide(): void;
  protected onToggle(event: Event): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<PopoverBase, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<PopoverBase, never, never, {
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Content that opens next to a button and closes on Escape or a click outside (the Popover
 * API). Open it with a PopoverTrigger.
 *
 * ```html
 * <button os-button [os-popover-trigger]="share">Share</button>
 * <div os-popover #share="osPopover" aria-label="Share">…</div>
 * ```
 */
export declare class Popover extends PopoverBase {
  static ɵfac: i0.ɵɵFactoryDeclaration<Popover, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Popover, "[os-popover]", ["osPopover"], {}, {}, never, never, true, never>;
}
/**
 * The button that opens a Popover or Menu. It's a native popovertarget, so the browser keeps
 * aria-expanded and returns focus to it when the popover closes.
 */
export declare class PopoverTrigger {
  readonly target: import("@angular/core").InputSignal<PopoverBase>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<PopoverTrigger, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<PopoverTrigger, "button[os-popover-trigger]", never, {
    "target": {
      "alias": "os-popover-trigger";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A list of actions that opens from a button. Arrow keys, Home and End move between items,
 * typing a letter jumps to an item, and choosing one closes the menu.
 *
 * ```html
 * <button os-button [os-popover-trigger]="actions" aria-haspopup="menu">Actions</button>
 * <div os-menu #actions="osPopover" aria-label="Actions">
 *   <button os-menu-item (click)="rename()">Rename</button>
 *   <hr os-menu-separator />
 *   <button os-menu-item tone="danger" (click)="remove()">Delete</button>
 * </div>
 * ```
 */
export declare class Menu extends PopoverBase {
  protected onToggle(event: Event): void;
  protected onKeydown(event: KeyboardEvent): void;
  protected onClick(event: MouseEvent): void;
  private items;
  static ɵfac: i0.ɵɵFactoryDeclaration<Menu, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Menu, "[os-menu]", ["osPopover"], {}, {}, never, never, true, never>;
}
/** An action in a Menu. `tone="danger"` for one that deletes. */
export declare class MenuItem {
  readonly tone: import("@angular/core").InputSignal<"danger" | "default">;
  protected readonly isButton: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MenuItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MenuItem, "button[os-menu-item], a[os-menu-item]", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class MenuSeparator {
  static ɵfac: i0.ɵɵFactoryDeclaration<MenuSeparator, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MenuSeparator, "hr[os-menu-separator]", never, {}, {}, never, never, true, never>;
}
export declare class MenuLabel {
  static ɵfac: i0.ɵɵFactoryDeclaration<MenuLabel, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MenuLabel, "[os-menu-label]", never, {}, {}, never, never, true, never>;
}
/**
 * A short hint that shows on hover or keyboard focus (interestfor and popover="hint", with a
 * fallback where they're missing). It also becomes the element's accessible description, unless
 * it repeats its name, as on an icon button.
 *
 * ```html
 * <button os-icon-button label="Copy link" os-tooltip="Copy link"><svg os-icon …></svg></button>
 * ```
 */
export declare class Tooltip {
  readonly text: import("@angular/core").InputSignal<string>;
  readonly placement: import("@angular/core").InputSignal<Placement>;
  protected readonly id: string;
  private readonly host;
  private readonly tip;
  constructor();
  protected describes(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<Tooltip, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Tooltip, "[os-tooltip]", never, {
    "text": {
      "alias": "os-tooltip";
      "required": true;
      "isSignal": true;
    };
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
interface ToastOptions {
  tone?: Tone;
  /** One button, such as Undo. Choosing it closes the toast. */
  action?: {
    label: string;
    run: () => void;
  };
  /**
   * How long it stays, in milliseconds. Defaults to 5 seconds, or 10 with an action; 0 keeps it
   * until it's closed. It pauses while the pointer is on it.
   */
  duration?: number;
}
/**
 * Short messages after an action, such as "Saved", in the corner of the screen. They're read
 * out by screen readers (role="status", or "alert" for the danger tone).
 *
 * ```ts
 * inject(Toaster).show('Draft deleted', { action: { label: 'Undo', run: restore } });
 * ```
 */
export declare class Toaster {
  private readonly app;
  private readonly injector;
  private region?;
  private next;
  /** Shows a toast and returns a function that closes it. */
  show(message: string, options?: ToastOptions): () => void;
  private getRegion;
  static ɵfac: i0.ɵɵFactoryDeclaration<Toaster, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
interface Column<T> {
  /** The property shown by default, and the name an `os-cell` template uses. */
  key: keyof T & string;
  label: string;
  align?: 'start' | 'end';
}
/**
 * How a column's cells render: `<ng-template os-cell="status" let-row>…</ng-template>`. The row
 * is untyped in the template, since a template can't see the table's row type.
 */
export declare class Cell {
  readonly key: import("@angular/core").InputSignal<string>;
  readonly template: TemplateRef<unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Cell, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Cell, "ng-template[os-cell]", never, {
    "key": {
      "alias": "os-cell";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A table that turns into stacked rows when its container is narrow. The first column is each
 * row's title. Roles are set explicitly, so screen readers still read a table when stacked.
 *
 * ```html
 * <os-data-table caption="Projects" [columns]="columns" [rows]="projects" rowKey="id">
 *   <ng-template os-cell="name" let-project>
 *     <a [routerLink]="project.id">{{ project.name }}</a>
 *   </ng-template>
 * </os-data-table>
 * ```
 */
export declare class DataTable<T extends object> {
  /** Names the table for screen readers (it's visually hidden). */
  readonly caption: import("@angular/core").InputSignal<string>;
  readonly columns: import("@angular/core").InputSignal<readonly Column<T>[]>;
  readonly rows: import("@angular/core").InputSignal<readonly T[]>;
  /** A property that identifies each row, so rows aren't re-created when the data changes. */
  readonly rowKey: import("@angular/core").InputSignal<keyof T | undefined>;
  /** Shown when there are no rows. */
  readonly empty: import("@angular/core").InputSignal<string>;
  private readonly cellTemplates;
  protected readonly cells: import("@angular/core").Signal<Partial<Record<string, TemplateRef<unknown>>>>;
  protected rowId(row: T, index: number): unknown;
  static ɵfac: i0.ɵɵFactoryDeclaration<DataTable<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DataTable<any>, "os-data-table", never, {
    "caption": {
      "alias": "caption";
      "required": true;
      "isSignal": true;
    };
    "columns": {
      "alias": "columns";
      "required": true;
      "isSignal": true;
    };
    "rows": {
      "alias": "rows";
      "required": true;
      "isSignal": true;
    };
    "rowKey": {
      "alias": "rowKey";
      "required": false;
      "isSignal": true;
    };
    "empty": {
      "alias": "empty";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["cellTemplates"], never, true, never>;
}
/**
 * One number with its label and an optional hint, such as a change since yesterday.
 *
 * ```html
 * <os-stat-tile label="Open findings" value="6" hint="2 need a decision" tone="warning" />
 * ```
 */
export declare class StatTile {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly value: import("@angular/core").InputSignal<string | number>;
  readonly hint: import("@angular/core").InputSignal<string | undefined>;
  /** Colours the hint: `success` for a good change, `danger` for a bad one. */
  readonly tone: import("@angular/core").InputSignal<Tone>;
  static ɵfac: i0.ɵɵFactoryDeclaration<StatTile, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<StatTile, "os-stat-tile", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class StatGrid {
  static ɵfac: i0.ɵɵFactoryDeclaration<StatGrid, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<StatGrid, "[os-stat-grid]", never, {}, {}, never, never, true, never>;
}
/**
 * A page's content area, centred with a maximum width. It's a size container, so everything in
 * it adapts to the space the page gets, not to the window.
 *
 * ```html
 * <main os-page width="narrow">…</main>
 * ```
 */
export declare class Page {
  readonly width: import("@angular/core").InputSignal<"default" | "narrow" | "full">;
  static ɵfac: i0.ɵɵFactoryDeclaration<Page, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Page, "[os-page]", never, {
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The page's title, an optional description, and its main actions (projected content).
 *
 * ```html
 * <header os-page-header title="Projects" description="Everything your team works on.">
 *   <button os-button variant="primary">New project</button>
 * </header>
 * ```
 */
export declare class PageHeader {
  readonly title: import("@angular/core").InputSignal<string>;
  readonly description: import("@angular/core").InputSignal<string | undefined>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PageHeader, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PageHeader, "header[os-page-header]", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * Where the page sits. Put an <ol> of links inside; mark the last item aria-current="page".
 *
 * ```html
 * <nav os-breadcrumbs>
 *   <ol>
 *     <li><a routerLink="/projects">Projects</a></li>
 *     <li><span aria-current="page">Design</span></li>
 *   </ol>
 * </nav>
 * ```
 */
export declare class Breadcrumbs {
  readonly label: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Breadcrumbs, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Breadcrumbs, "nav[os-breadcrumbs]", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A bordered section with an optional title, description and actions (`os-actions`).
 *
 * ```html
 * <section os-panel title="Members" description="People who can edit this project.">
 *   <button os-button os-actions size="sm">Invite</button>
 *   …
 * </section>
 * ```
 */
export declare class Panel {
  readonly title: import("@angular/core").InputSignal<string | undefined>;
  readonly description: import("@angular/core").InputSignal<string | undefined>;
  /** The title's heading level, to fit the page's outline. */
  readonly level: import("@angular/core").InputSignalWithTransform<number, unknown>;
  /** No padding inside, for a table or list that runs edge to edge. */
  readonly flush: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly titleId: string;
  static ɵfac: i0.ɵɵFactoryDeclaration<Panel, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Panel, "[os-panel]", never, {
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
    "level": {
      "alias": "level";
      "required": false;
      "isSignal": true;
    };
    "flush": {
      "alias": "flush";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[os-actions]", "*"], true, never>;
}
/** A card. On an <a> or <button>, the whole card is clickable. */
export declare class Card {
  static ɵfac: i0.ɵɵFactoryDeclaration<Card, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Card, "[os-card]", never, {}, {}, never, never, true, never>;
}
/** Lays out cards in as many columns as fit. */
export declare class CardGrid {
  static ɵfac: i0.ɵɵFactoryDeclaration<CardGrid, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<CardGrid, "[os-card-grid]", never, {}, {}, never, never, true, never>;
}
/**
 * One tab of a Tabs: its label and, inside the template, its content (rendered when chosen).
 */
export declare class Tab {
  readonly value: import("@angular/core").InputSignal<string>;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly template: TemplateRef<unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Tab, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<Tab, "ng-template[os-tab]", never, {
    "value": {
      "alias": "os-tab";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Tabs that switch between views in one place. Arrow keys move between tabs and show them,
 * Home and End jump to the ends (from @angular/aria).
 *
 * ```html
 * <os-tabs label="Project" [(selected)]="tab">
 *   <ng-template os-tab="overview" label="Overview">…</ng-template>
 *   <ng-template os-tab="rules" label="Rules">…</ng-template>
 * </os-tabs>
 * ```
 */
export declare class Tabs {
  /** Names the tab list for screen readers. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The chosen tab's value. Defaults to the first tab. */
  readonly selected: import("@angular/core").ModelSignal<string | undefined>;
  protected readonly tabs: import("@angular/core").Signal<readonly Tab[]>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<Tabs, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Tabs, "os-tabs", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
  }, ["tabs"], never, true, [{
    directive: typeof i1.Tabs;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * A group of settings with a title, rows and an optional footer
 * (`<footer os-setting-card-footer>`).
 *
 * ```html
 * <section os-setting-card title="Profile" description="How others see you.">
 *   <os-setting-row label="Name"><input os-input [(ngModel)]="name" /></os-setting-row>
 *   <footer os-setting-card-footer><div os-form-actions>…</div></footer>
 * </section>
 * ```
 */
export declare class SettingCard {
  readonly title: import("@angular/core").InputSignal<string>;
  readonly description: import("@angular/core").InputSignal<string | undefined>;
  readonly level: import("@angular/core").InputSignalWithTransform<number, unknown>;
  /** `danger` for a card of actions that delete or can't be undone. */
  readonly tone: import("@angular/core").InputSignal<"neutral" | "danger">;
  protected readonly titleId: string;
  static ɵfac: i0.ɵɵFactoryDeclaration<SettingCard, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SettingCard, "[os-setting-card]", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
    "level": {
      "alias": "level";
      "required": false;
      "isSignal": true;
    };
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export declare class SettingCardFooter {
  static ɵfac: i0.ɵɵFactoryDeclaration<SettingCardFooter, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SettingCardFooter, "[os-setting-card-footer]", never, {}, {}, never, never, true, never>;
}
/**
 * One setting: its label and description on the left, the control on the right (stacked in a
 * narrow card). The control inside gets the label and description wired up, like in a Field.
 *
 * ```html
 * <os-setting-row label="Agent mode" description="Shows what agents read." inline>
 *   <input type="checkbox" os-switch [(ngModel)]="agentMode" />
 * </os-setting-row>
 * ```
 */
export declare class SettingRow implements FieldContext {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly description: import("@angular/core").InputSignal<string | undefined>;
  /** Keeps a small control (a switch, a button) at the end of the row instead of below. */
  readonly inline: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly controlId: string;
  protected readonly descriptionId: string;
  readonly describedBy: import("@angular/core").Signal<string | null>;
  readonly invalid: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SettingRow, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SettingRow, "os-setting-row", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
    "inline": {
      "alias": "inline";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * A form's buttons, at the end, stacked full width in a narrow container. Put the main action
 * last. A `<span os-form-actions-note>` goes at the start.
 */
export declare class FormActions {
  static ɵfac: i0.ɵɵFactoryDeclaration<FormActions, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FormActions, "[os-form-actions]", never, {}, {}, never, never, true, never>;
}
export declare class FormActionsNote {
  static ɵfac: i0.ɵɵFactoryDeclaration<FormActionsNote, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FormActionsNote, "[os-form-actions-note]", never, {}, {}, never, never, true, never>;
}
export type { ButtonSize, ButtonVariant, ClosedBy, Column, Command, ConfirmOptions, FieldContext, Placement, SegmentOption, ToastOptions, Tone };