import * as i0 from "@angular/core";
import { ApplicationRef, ChangeDetectionStrategy, Component, DestroyRef, Directive, ElementRef, EnvironmentInjector, Injectable, InjectionToken, TemplateRef, afterNextRender, booleanAttribute, computed, contentChildren, createComponent, effect, inject, input, model, numberAttribute, output, signal } from "@angular/core";
import { anchor, iconCircleAlert, iconCircleCheck, iconInfo, iconSearch, iconTriangleAlert, iconX, renderIcon } from "@openstuff-dev/ui";
import { NgTemplateOutlet } from "@angular/common";
import * as i1 from "@angular/aria/tabs";
import { Tab as Tab$1, TabContent, TabList, TabPanel, Tabs as Tabs$1 } from "@angular/aria/tabs";
var Icon = class Icon {
	icon = input.required(...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	flipInRtl = input(false, ...ngDevMode ? [{ debugName: "flipInRtl" }] : /* istanbul ignore next */ []);
	constructor() {
		const svg = inject(ElementRef).nativeElement;
		effect(() => {
			renderIcon(svg, this.icon());
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Icon,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Icon,
		isStandalone: true,
		selector: "svg[os-icon]",
		inputs: {
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flipInRtl: {
				classPropertyName: "flipInRtl",
				publicName: "flipInRtl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: {
				"viewBox": "0 0 24 24",
				"aria-hidden": "true",
				"focusable": "false"
			},
			properties: {
				"attr.data-size": "size() === \"md\" ? null : size()",
				"attr.data-flip-rtl": "flipInRtl() ? \"\" : null"
			},
			classAttribute: "os-icon"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Icon,
	decorators: [{
		type: Directive,
		args: [{
			selector: "svg[os-icon]",
			host: {
				class: "os-icon",
				viewBox: "0 0 24 24",
				"aria-hidden": "true",
				focusable: "false",
				"[attr.data-size]": "size() === \"md\" ? null : size()",
				"[attr.data-flip-rtl]": "flipInRtl() ? \"\" : null"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: true
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		flipInRtl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flipInRtl",
				required: false
			}]
		}]
	}
});
let next = 0;
function uniqueId(prefix) {
	return `os-${prefix}-${String(next++)}`;
}
var Badge = class Badge {
	tone = input("neutral", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Badge,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Badge,
		isStandalone: true,
		selector: "[os-badge]",
		inputs: { tone: {
			classPropertyName: "tone",
			publicName: "tone",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: { "attr.data-tone": "tone()" },
			classAttribute: "os-badge"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Badge,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-badge]",
			host: {
				class: "os-badge",
				"[attr.data-tone]": "tone()"
			}
		}]
	}],
	propDecorators: { tone: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "tone",
			required: false
		}]
	}] }
});
var Chip = class Chip {
	tone = input("neutral", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	removable = input(false, {
		...ngDevMode ? { debugName: "removable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	removed = output();
	iconX = iconX;
	textId = uniqueId("chip");
	buttonId = uniqueId("chip-remove");
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Chip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: Chip,
		isStandalone: true,
		selector: "[os-chip]",
		inputs: {
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			removable: {
				classPropertyName: "removable",
				publicName: "removable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { removed: "removed" },
		host: {
			properties: { "attr.data-tone": "tone()" },
			classAttribute: "os-chip"
		},
		ngImport: i0,
		template: `
    <span [id]="textId">
      <ng-content />
    </span>
    @if (removable()) {
      <button
        class="os-chip-remove"
        type="button"
        [id]="buttonId"
        [attr.aria-labelledby]="buttonId + ' ' + textId"
        (click)="removed.emit()"
      >
        <svg os-icon [icon]="iconX"></svg>
        <span class="os-visually-hidden">Remove</span>
      </button>
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: Icon,
			selector: "svg[os-icon]",
			inputs: [
				"icon",
				"size",
				"flipInRtl"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Chip,
	decorators: [{
		type: Component,
		args: [{
			selector: "[os-chip]",
			imports: [Icon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "os-chip",
				"[attr.data-tone]": "tone()"
			},
			template: `
    <span [id]="textId">
      <ng-content />
    </span>
    @if (removable()) {
      <button
        class="os-chip-remove"
        type="button"
        [id]="buttonId"
        [attr.aria-labelledby]="buttonId + ' ' + textId"
        (click)="removed.emit()"
      >
        <svg os-icon [icon]="iconX"></svg>
        <span class="os-visually-hidden">Remove</span>
      </button>
    }
  `
		}]
	}],
	propDecorators: {
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		removable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "removable",
				required: false
			}]
		}],
		removed: [{
			type: i0.Output,
			args: ["removed"]
		}]
	}
});
var StatusDot = class StatusDot {
	tone = input("neutral", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	pulse = input(false, {
		...ngDevMode ? { debugName: "pulse" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StatusDot,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: StatusDot,
		isStandalone: true,
		selector: "[os-status-dot]",
		inputs: {
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pulse: {
				classPropertyName: "pulse",
				publicName: "pulse",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-tone": "tone()",
				"attr.data-pulse": "pulse() ? \"\" : null"
			},
			classAttribute: "os-status-dot"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StatusDot,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-status-dot]",
			host: {
				class: "os-status-dot",
				"[attr.data-tone]": "tone()",
				"[attr.data-pulse]": "pulse() ? \"\" : null"
			}
		}]
	}],
	propDecorators: {
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		pulse: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pulse",
				required: false
			}]
		}]
	}
});
var Button = class Button {
	variant = input("default", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	loading = input(false, {
		...ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	constructor() {
		inject(ElementRef).nativeElement.addEventListener("click", (event) => {
			if (this.loading()) {
				event.preventDefault();
				event.stopImmediatePropagation();
			}
		}, { capture: true });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Button,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Button,
		isStandalone: true,
		selector: "button[os-button], a[os-button]",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loading: {
				classPropertyName: "loading",
				publicName: "loading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-variant": "variant()",
				"attr.data-size": "size()",
				"attr.aria-busy": "loading() || null",
				"attr.aria-disabled": "loading() || null"
			},
			classAttribute: "os-button"
		},
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Button,
	decorators: [{
		type: Component,
		args: [{
			selector: "button[os-button], a[os-button]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: {
				class: "os-button",
				"[attr.data-variant]": "variant()",
				"[attr.data-size]": "size()",
				"[attr.aria-busy]": "loading() || null",
				"[attr.aria-disabled]": "loading() || null"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		loading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}]
	}
});
var IconButton = class IconButton extends Button {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: IconButton,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: IconButton,
		isStandalone: true,
		selector: "button[os-icon-button], a[os-icon-button]",
		inputs: { label: {
			classPropertyName: "label",
			publicName: "label",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			attributes: { "data-icon-only": "" },
			properties: {
				"attr.data-variant": "variant()",
				"attr.data-size": "size()",
				"attr.aria-label": "label()",
				"attr.aria-busy": "loading() || null",
				"attr.aria-disabled": "loading() || null"
			},
			classAttribute: "os-button"
		},
		usesInheritance: true,
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: IconButton,
	decorators: [{
		type: Component,
		args: [{
			selector: "button[os-icon-button], a[os-icon-button]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: {
				class: "os-button",
				"data-icon-only": "",
				"[attr.data-variant]": "variant()",
				"[attr.data-size]": "size()",
				"[attr.aria-label]": "label()",
				"[attr.aria-busy]": "loading() || null",
				"[attr.aria-disabled]": "loading() || null"
			}
		}]
	}],
	propDecorators: { label: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "label",
			required: true
		}]
	}] }
});
const TONE_ICONS = {
	neutral: iconInfo,
	brand: iconInfo,
	info: iconInfo,
	success: iconCircleCheck,
	warning: iconTriangleAlert,
	danger: iconCircleAlert
};
var Callout = class Callout {
	tone = input("info", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	title = input(...ngDevMode ? [void 0, { debugName: "title" }] : /* istanbul ignore next */ []);
	icon = computed(() => TONE_ICONS[this.tone()], ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Callout,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: Callout,
		isStandalone: true,
		selector: "os-callout",
		inputs: {
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: { "attr.data-tone": "tone()" },
			classAttribute: "os-callout"
		},
		ngImport: i0,
		template: `
    <svg os-icon [icon]="icon()"></svg>
    <div>
      @if (title()) {
        <p class="os-callout-title">{{ title() }}</p>
      }
      <div><ng-content /></div>
      <div class="os-callout-actions"><ng-content select="[os-actions]" /></div>
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: Icon,
			selector: "svg[os-icon]",
			inputs: [
				"icon",
				"size",
				"flipInRtl"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Callout,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-callout",
			imports: [Icon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "os-callout",
				"[attr.data-tone]": "tone()"
			},
			template: `
    <svg os-icon [icon]="icon()"></svg>
    <div>
      @if (title()) {
        <p class="os-callout-title">{{ title() }}</p>
      }
      <div><ng-content /></div>
      <div class="os-callout-actions"><ng-content select="[os-actions]" /></div>
    </div>
  `
		}]
	}],
	propDecorators: {
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}]
	}
});
var EmptyState = class EmptyState {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	level = input(3, {
		...ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	bordered = input(false, {
		...ngDevMode ? { debugName: "bordered" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: EmptyState,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: EmptyState,
		isStandalone: true,
		selector: "os-empty-state",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			level: {
				classPropertyName: "level",
				publicName: "level",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			bordered: {
				classPropertyName: "bordered",
				publicName: "bordered",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: { "attr.data-bordered": "bordered() ? \"\" : null" },
			classAttribute: "os-empty-state"
		},
		ngImport: i0,
		template: `
    @if (icon(); as icon) {
      <svg os-icon [icon]="icon"></svg>
    }
    <p class="os-empty-state-title" role="heading" [attr.aria-level]="level()">{{ title() }}</p>
    <p><ng-content /></p>
    <div class="os-empty-state-actions"><ng-content select="[os-actions]" /></div>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: Icon,
			selector: "svg[os-icon]",
			inputs: [
				"icon",
				"size",
				"flipInRtl"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: EmptyState,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-empty-state",
			imports: [Icon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "os-empty-state",
				"[attr.data-bordered]": "bordered() ? \"\" : null"
			},
			template: `
    @if (icon(); as icon) {
      <svg os-icon [icon]="icon"></svg>
    }
    <p class="os-empty-state-title" role="heading" [attr.aria-level]="level()">{{ title() }}</p>
    <p><ng-content /></p>
    <div class="os-empty-state-actions"><ng-content select="[os-actions]" /></div>
  `
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		level: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "level",
				required: false
			}]
		}],
		bordered: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bordered",
				required: false
			}]
		}]
	}
});
var Kbd = class Kbd {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Kbd,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: Kbd,
		isStandalone: true,
		selector: "kbd[os-kbd]",
		host: { classAttribute: "os-kbd" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Kbd,
	decorators: [{
		type: Directive,
		args: [{
			selector: "kbd[os-kbd]",
			host: { class: "os-kbd" }
		}]
	}]
});
var Skeleton = class Skeleton {
	lines = input(1, {
		...ngDevMode ? { debugName: "lines" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	shape = input("text", ...ngDevMode ? [{ debugName: "shape" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Skeleton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Skeleton,
		isStandalone: true,
		selector: "os-skeleton",
		inputs: {
			lines: {
				classPropertyName: "lines",
				publicName: "lines",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shape: {
				classPropertyName: "shape",
				publicName: "shape",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "aria-hidden": "true" },
			properties: {
				"attr.data-shape": "shape() === \"circle\" ? \"circle\" : null",
				"style.--os-skeleton-lines": "lines()"
			},
			classAttribute: "os-skeleton"
		},
		ngImport: i0,
		template: "",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Skeleton,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-skeleton",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "os-skeleton",
				"aria-hidden": "true",
				"[attr.data-shape]": "shape() === \"circle\" ? \"circle\" : null",
				"[style.--os-skeleton-lines]": "lines()"
			},
			template: ""
		}]
	}],
	propDecorators: {
		lines: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lines",
				required: false
			}]
		}],
		shape: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shape",
				required: false
			}]
		}]
	}
});
const FIELD = new InjectionToken("FIELD");
var Field = class Field {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	hint = input(...ngDevMode ? [void 0, { debugName: "hint" }] : /* istanbul ignore next */ []);
	error = input(...ngDevMode ? [void 0, { debugName: "error" }] : /* istanbul ignore next */ []);
	controlId = uniqueId("control");
	hintId = uniqueId("hint");
	errorId = uniqueId("error");
	iconCircleAlert = iconCircleAlert;
	invalid = computed(() => Boolean(this.error()), ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => [this.hint() && this.hintId, this.error() && this.errorId].filter(Boolean).join(" ") || null, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Field,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: Field,
		isStandalone: true,
		selector: "os-field",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			error: {
				classPropertyName: "error",
				publicName: "error",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "os-field" },
		providers: [{
			provide: FIELD,
			useExisting: Field
		}],
		ngImport: i0,
		template: `
    <label class="os-label" [for]="controlId">{{ label() }}</label>
    <ng-content />
    @if (hint()) {
      <p class="os-hint" [id]="hintId">{{ hint() }}</p>
    }
    @if (error()) {
      <p class="os-error" [id]="errorId">
        <svg os-icon [icon]="iconCircleAlert"></svg>
        {{ error() }}
      </p>
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: Icon,
			selector: "svg[os-icon]",
			inputs: [
				"icon",
				"size",
				"flipInRtl"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Field,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-field",
			imports: [Icon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: FIELD,
				useExisting: Field
			}],
			host: { class: "os-field" },
			template: `
    <label class="os-label" [for]="controlId">{{ label() }}</label>
    <ng-content />
    @if (hint()) {
      <p class="os-hint" [id]="hintId">{{ hint() }}</p>
    }
    @if (error()) {
      <p class="os-error" [id]="errorId">
        <svg os-icon [icon]="iconCircleAlert"></svg>
        {{ error() }}
      </p>
    }
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		error: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "error",
				required: false
			}]
		}]
	}
});
var Control = class Control {
	field = inject(FIELD, { optional: true });
	tag = inject(ElementRef).nativeElement.tagName;
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	invalid = input(false, {
		...ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	id = input(this.field?.controlId ?? uniqueId("control"), ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	isInvalid = computed(() => this.invalid() || (this.field?.invalid() ?? false), ...ngDevMode ? [{ debugName: "isInvalid" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Control,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Control,
		isStandalone: true,
		selector: "input[os-input], textarea[os-textarea], select[os-select]",
		inputs: {
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: {
			"class.os-input": "tag === \"INPUT\"",
			"class.os-textarea": "tag === \"TEXTAREA\"",
			"class.os-select": "tag === \"SELECT\"",
			"attr.data-size": "size() === \"md\" ? null : size()",
			"id": "id()",
			"attr.aria-describedby": "field?.describedBy() ?? null",
			"attr.aria-invalid": "isInvalid() || null"
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Control,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[os-input], textarea[os-textarea], select[os-select]",
			host: {
				"[class.os-input]": "tag === \"INPUT\"",
				"[class.os-textarea]": "tag === \"TEXTAREA\"",
				"[class.os-select]": "tag === \"SELECT\"",
				"[attr.data-size]": "size() === \"md\" ? null : size()",
				"[id]": "id()",
				"[attr.aria-describedby]": "field?.describedBy() ?? null",
				"[attr.aria-invalid]": "isInvalid() || null"
			}
		}]
	}],
	propDecorators: {
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: false
			}]
		}]
	}
});
var Check = class Check {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Check,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: Check,
		isStandalone: true,
		selector: "label[os-check]",
		host: { classAttribute: "os-check" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Check,
	decorators: [{
		type: Directive,
		args: [{
			selector: "label[os-check]",
			host: { class: "os-check" }
		}]
	}]
});
var Checkbox = class Checkbox {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Checkbox,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: Checkbox,
		isStandalone: true,
		selector: "input[type=checkbox][os-checkbox]",
		host: { classAttribute: "os-checkbox" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Checkbox,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[type=checkbox][os-checkbox]",
			host: { class: "os-checkbox" }
		}]
	}]
});
var Radio = class Radio {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Radio,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: Radio,
		isStandalone: true,
		selector: "input[type=radio][os-radio]",
		host: { classAttribute: "os-radio" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Radio,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[type=radio][os-radio]",
			host: { class: "os-radio" }
		}]
	}]
});
var Switch = class Switch {
	field = inject(FIELD, { optional: true });
	id = input(this.field?.controlId ?? uniqueId("switch"), ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Switch,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Switch,
		isStandalone: true,
		selector: "input[type=checkbox][os-switch]",
		inputs: { id: {
			classPropertyName: "id",
			publicName: "id",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "role": "switch" },
			properties: {
				"id": "id()",
				"attr.aria-describedby": "field?.describedBy() ?? null"
			},
			classAttribute: "os-switch"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Switch,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[type=checkbox][os-switch]",
			host: {
				class: "os-switch",
				role: "switch",
				"[id]": "id()",
				"[attr.aria-describedby]": "field?.describedBy() ?? null"
			}
		}]
	}],
	propDecorators: { id: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "id",
			required: false
		}]
	}] }
});
var Fieldset = class Fieldset {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Fieldset,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: Fieldset,
		isStandalone: true,
		selector: "fieldset[os-fieldset]",
		host: { classAttribute: "os-fieldset" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Fieldset,
	decorators: [{
		type: Directive,
		args: [{
			selector: "fieldset[os-fieldset]",
			host: { class: "os-fieldset" }
		}]
	}]
});
var SegmentedControl = class SegmentedControl {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	value = model(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	name = input(uniqueId("segmented"), ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SegmentedControl,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: SegmentedControl,
		isStandalone: true,
		selector: "os-segmented-control",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: {
			attributes: { "role": "radiogroup" },
			properties: {
				"attr.aria-label": "label()",
				"attr.data-size": "size() === \"md\" ? null : size()"
			},
			classAttribute: "os-segmented"
		},
		ngImport: i0,
		template: `
    @for (option of options(); track option.value) {
      <label>
        <input
          type="radio"
          [name]="name()"
          [value]="option.value"
          [checked]="option.value === value()"
          [disabled]="option.disabled ?? false"
          (change)="value.set(option.value)"
        />
        {{ option.label }}
      </label>
    }
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SegmentedControl,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-segmented-control",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "os-segmented",
				role: "radiogroup",
				"[attr.aria-label]": "label()",
				"[attr.data-size]": "size() === \"md\" ? null : size()"
			},
			template: `
    @for (option of options(); track option.value) {
      <label>
        <input
          type="radio"
          [name]="name()"
          [value]="option.value"
          [checked]="option.value === value()"
          [disabled]="option.disabled ?? false"
          (change)="value.set(option.value)"
        />
        {{ option.label }}
      </label>
    }
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}]
	}
});
var DialogBase = class DialogBase {
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	closedby = input("any", ...ngDevMode ? [{ debugName: "closedby" }] : /* istanbul ignore next */ []);
	nonModal = input(false, {
		...ngDevMode ? { debugName: "nonModal" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	element = inject(ElementRef).nativeElement;
	titleId = signal(null, ...ngDevMode ? [{ debugName: "titleId" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const dialog = this.element;
			if (this.open() && !dialog.open) {
				if (this.nonModal()) dialog.show();
				else dialog.showModal();
			} else if (!this.open() && dialog.open) dialog.close();
		});
	}
	close(returnValue) {
		this.element.close(returnValue);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogBase,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DialogBase,
		isStandalone: true,
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closedby: {
				classPropertyName: "closedby",
				publicName: "closedby",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			nonModal: {
				classPropertyName: "nonModal",
				publicName: "nonModal",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		host: {
			listeners: { "close": "open.set(false)" },
			properties: {
				"attr.closedby": "closedby()",
				"attr.aria-labelledby": "titleId()"
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogBase,
	decorators: [{
		type: Directive,
		args: [{ host: {
			"[attr.closedby]": "closedby()",
			"[attr.aria-labelledby]": "titleId()",
			"(close)": "open.set(false)"
		} }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		closedby: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closedby",
				required: false
			}]
		}],
		nonModal: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "nonModal",
				required: false
			}]
		}]
	}
});
var Dialog = class Dialog extends DialogBase {
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Dialog,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Dialog,
		isStandalone: true,
		selector: "dialog[os-dialog]",
		inputs: { size: {
			classPropertyName: "size",
			publicName: "size",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: { "attr.data-size": "size() === \"md\" ? null : size()" },
			classAttribute: "os-dialog"
		},
		providers: [{
			provide: DialogBase,
			useExisting: Dialog
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Dialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "dialog[os-dialog]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: DialogBase,
				useExisting: Dialog
			}],
			host: {
				class: "os-dialog",
				"[attr.data-size]": "size() === \"md\" ? null : size()"
			},
			template: "<ng-content />"
		}]
	}],
	propDecorators: { size: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "size",
			required: false
		}]
	}] }
});
var Drawer = class Drawer extends DialogBase {
	side = input("end", ...ngDevMode ? [{ debugName: "side" }] : /* istanbul ignore next */ []);
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Drawer,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Drawer,
		isStandalone: true,
		selector: "dialog[os-drawer]",
		inputs: {
			side: {
				classPropertyName: "side",
				publicName: "side",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-side": "side() === \"end\" ? null : side()",
				"attr.data-size": "size() === \"md\" ? null : size()"
			},
			classAttribute: "os-drawer"
		},
		providers: [{
			provide: DialogBase,
			useExisting: Drawer
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Drawer,
	decorators: [{
		type: Component,
		args: [{
			selector: "dialog[os-drawer]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: DialogBase,
				useExisting: Drawer
			}],
			host: {
				class: "os-drawer",
				"[attr.data-side]": "side() === \"end\" ? null : side()",
				"[attr.data-size]": "size() === \"md\" ? null : size()"
			},
			template: "<ng-content />"
		}]
	}],
	propDecorators: {
		side: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "side",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}]
	}
});
var DialogHeader = class DialogHeader {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogHeader,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DialogHeader,
		isStandalone: true,
		selector: "[os-dialog-header]",
		host: { classAttribute: "os-dialog-header" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogHeader,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-dialog-header]",
			host: { class: "os-dialog-header" }
		}]
	}]
});
var DialogBody = class DialogBody {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogBody,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DialogBody,
		isStandalone: true,
		selector: "[os-dialog-body]",
		host: { classAttribute: "os-dialog-body" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogBody,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-dialog-body]",
			host: { class: "os-dialog-body" }
		}]
	}]
});
var DialogFooter = class DialogFooter {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogFooter,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DialogFooter,
		isStandalone: true,
		selector: "[os-dialog-footer]",
		host: { classAttribute: "os-dialog-footer" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogFooter,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-dialog-footer]",
			host: { class: "os-dialog-footer" }
		}]
	}]
});
var DialogTitle = class DialogTitle {
	id = uniqueId("dialog-title");
	constructor() {
		inject(DialogBase).titleId.set(this.id);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogTitle,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DialogTitle,
		isStandalone: true,
		selector: "[os-dialog-title]",
		host: { properties: { "id": "id" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogTitle,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-dialog-title]",
			host: { "[id]": "id" }
		}]
	}],
	ctorParameters: () => []
});
var DialogClose = class DialogClose {
	dialog = inject(DialogBase);
	returnValue = input("", {
		...ngDevMode ? { debugName: "returnValue" } : /* istanbul ignore next */ {},
		alias: "os-dialog-close"
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogClose,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DialogClose,
		isStandalone: true,
		selector: "button[os-dialog-close]",
		inputs: { returnValue: {
			classPropertyName: "returnValue",
			publicName: "os-dialog-close",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "type": "button" },
			listeners: { "click": "dialog.close(returnValue() || undefined)" }
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogClose,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[os-dialog-close]",
			host: {
				type: "button",
				"(click)": "dialog.close(returnValue() || undefined)"
			}
		}]
	}],
	propDecorators: { returnValue: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "os-dialog-close",
			required: false
		}]
	}] }
});
function matchesQuery(command, query) {
	const text = [
		command.label,
		command.group ?? "",
		...command.keywords ?? []
	].join(" ").toLowerCase();
	return query.toLowerCase().split(/\s+/).filter(Boolean).every((word) => text.includes(word));
}
var CommandPalette = class CommandPalette {
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	commands = input.required(...ngDevMode ? [{ debugName: "commands" }] : /* istanbul ignore next */ []);
	label = input("Commands", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	placeholder = input("Search pages and actions", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	run = output();
	iconSearch = iconSearch;
	listId = uniqueId("commands");
	query = signal("", ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	active = signal(void 0, ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	prefix = uniqueId("command");
	results = computed(() => this.commands().filter((command) => matchesQuery(command, this.query())), ...ngDevMode ? [{ debugName: "results" }] : /* istanbul ignore next */ []);
	groups = computed(() => {
		const groups = /* @__PURE__ */ new Map();
		for (const command of this.results()) {
			let group = groups.get(command.group);
			if (!group) {
				group = {
					name: command.group,
					id: `${this.prefix}-group-${String(groups.size)}`,
					commands: []
				};
				groups.set(command.group, group);
			}
			group.commands.push({
				command,
				id: `${this.prefix}-${command.id}`
			});
		}
		return [...groups.values()];
	}, ...ngDevMode ? [{ debugName: "groups" }] : /* istanbul ignore next */ []);
	ordered = computed(() => this.groups().flatMap((group) => group.commands.map((item) => item.command)), ...ngDevMode ? [{ debugName: "ordered" }] : /* istanbul ignore next */ []);
	activeId = computed(() => {
		const active = this.active();
		const current = active && this.ordered().includes(active) ? active : this.ordered().at(0);
		return current ? `${this.prefix}-${current.id}` : null;
	}, ...ngDevMode ? [{ debugName: "activeId" }] : /* istanbul ignore next */ []);
	onInput(value) {
		this.query.set(value);
		this.active.set(void 0);
	}
	onKeydown(event) {
		const list = this.ordered();
		if (!list.length) return;
		const index = Math.max(0, list.findIndex((command) => `${this.prefix}-${command.id}` === this.activeId()));
		const next = {
			ArrowDown: Math.min(index + 1, list.length - 1),
			ArrowUp: Math.max(index - 1, 0),
			PageDown: Math.min(index + 5, list.length - 1),
			PageUp: Math.max(index - 5, 0)
		};
		if (event.key === "Enter") {
			event.preventDefault();
			this.choose(list[index]);
			return;
		}
		const target = next[event.key];
		if (target === void 0) return;
		event.preventDefault();
		this.active.set(list[target]);
		const id = `${this.prefix}-${list[target].id}`;
		queueMicrotask(() => document.getElementById(id)?.scrollIntoView({ block: "nearest" }));
	}
	choose(command) {
		if (!command) return;
		this.open.set(false);
		this.run.emit(command);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CommandPalette,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: CommandPalette,
		isStandalone: true,
		selector: "os-command-palette",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			commands: {
				classPropertyName: "commands",
				publicName: "commands",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			open: "openChange",
			run: "run"
		},
		ngImport: i0,
		template: `
    <dialog
      os-dialog
      class="os-command-palette"
      [attr.aria-label]="label()"
      [(open)]="open"
      (close)="query.set('')"
    >
      <div class="os-command-search">
        <svg os-icon [icon]="iconSearch"></svg>
        <input
          #search
          role="combobox"
          aria-autocomplete="list"
          aria-expanded="true"
          autocomplete="off"
          spellcheck="false"
          [attr.aria-controls]="listId"
          [attr.aria-activedescendant]="activeId()"
          [attr.aria-label]="label()"
          [placeholder]="placeholder()"
          [value]="query()"
          (input)="onInput(search.value)"
          (keydown)="onKeydown($event)"
        />
        <kbd os-kbd aria-hidden="true">Esc</kbd>
      </div>
      <div class="os-command-list" role="listbox" [id]="listId" [attr.aria-label]="label()">
        @for (group of groups(); track group.id) {
          <div
            class="os-command-group"
            role="group"
            [attr.aria-labelledby]="group.name ? group.id : null"
          >
            @if (group.name) {
              <div class="os-command-group-label" [id]="group.id">{{ group.name }}</div>
            }
            @for (item of group.commands; track item.id) {
              <!-- The search box handles the keyboard (aria-activedescendant); this is for pointers. -->
              <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
              <div
                class="os-command-item"
                role="option"
                [id]="item.id"
                [attr.aria-selected]="item.id === activeId()"
                (click)="choose(item.command)"
                (pointermove)="active.set(item.command)"
              >
                @if (item.command.icon; as icon) {
                  <svg os-icon [icon]="icon"></svg>
                }
                {{ item.command.label }}
                @if (item.command.hint) {
                  <span class="os-command-hint">{{ item.command.hint }}</span>
                }
              </div>
            }
          </div>
        } @empty {
          <p class="os-command-empty" role="status">No results for "{{ query() }}"</p>
        }
      </div>
    </dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Dialog,
				selector: "dialog[os-dialog]",
				inputs: ["size"]
			},
			{
				kind: "directive",
				type: Icon,
				selector: "svg[os-icon]",
				inputs: [
					"icon",
					"size",
					"flipInRtl"
				]
			},
			{
				kind: "directive",
				type: Kbd,
				selector: "kbd[os-kbd]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CommandPalette,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-command-palette",
			imports: [
				Dialog,
				Icon,
				Kbd
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <dialog
      os-dialog
      class="os-command-palette"
      [attr.aria-label]="label()"
      [(open)]="open"
      (close)="query.set('')"
    >
      <div class="os-command-search">
        <svg os-icon [icon]="iconSearch"></svg>
        <input
          #search
          role="combobox"
          aria-autocomplete="list"
          aria-expanded="true"
          autocomplete="off"
          spellcheck="false"
          [attr.aria-controls]="listId"
          [attr.aria-activedescendant]="activeId()"
          [attr.aria-label]="label()"
          [placeholder]="placeholder()"
          [value]="query()"
          (input)="onInput(search.value)"
          (keydown)="onKeydown($event)"
        />
        <kbd os-kbd aria-hidden="true">Esc</kbd>
      </div>
      <div class="os-command-list" role="listbox" [id]="listId" [attr.aria-label]="label()">
        @for (group of groups(); track group.id) {
          <div
            class="os-command-group"
            role="group"
            [attr.aria-labelledby]="group.name ? group.id : null"
          >
            @if (group.name) {
              <div class="os-command-group-label" [id]="group.id">{{ group.name }}</div>
            }
            @for (item of group.commands; track item.id) {
              <!-- The search box handles the keyboard (aria-activedescendant); this is for pointers. -->
              <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
              <div
                class="os-command-item"
                role="option"
                [id]="item.id"
                [attr.aria-selected]="item.id === activeId()"
                (click)="choose(item.command)"
                (pointermove)="active.set(item.command)"
              >
                @if (item.command.icon; as icon) {
                  <svg os-icon [icon]="icon"></svg>
                }
                {{ item.command.label }}
                @if (item.command.hint) {
                  <span class="os-command-hint">{{ item.command.hint }}</span>
                }
              </div>
            }
          </div>
        } @empty {
          <p class="os-command-empty" role="status">No results for "{{ query() }}"</p>
        }
      </div>
    </dialog>
  `
		}]
	}],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		commands: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "commands",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		run: [{
			type: i0.Output,
			args: ["run"]
		}]
	}
});
var ConfirmDialogView = class ConfirmDialogView {
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	closed = output();
	messageId = uniqueId("confirm-message");
	onClose(event) {
		this.closed.emit(event.target.returnValue === "confirm");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ConfirmDialogView,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ConfirmDialogView,
		isStandalone: true,
		selector: "os-confirm-dialog",
		inputs: { options: {
			classPropertyName: "options",
			publicName: "options",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		outputs: { closed: "closed" },
		ngImport: i0,
		template: `
    <dialog
      os-dialog
      size="sm"
      closedby="closerequest"
      [open]="true"
      [attr.aria-describedby]="messageId"
      (close)="onClose($event)"
    >
      <header os-dialog-header>
        <h2 os-dialog-title>{{ options().title }}</h2>
      </header>
      <div os-dialog-body>
        <p [id]="messageId">{{ options().message }}</p>
      </div>
      <footer os-dialog-footer>
        <button os-button os-dialog-close type="button" autofocus>
          {{ options().cancelLabel ?? 'Cancel' }}
        </button>
        <button
          os-button
          os-dialog-close="confirm"
          type="button"
          [variant]="options().danger ? 'danger' : 'primary'"
        >
          {{ options().confirmLabel }}
        </button>
      </footer>
    </dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Button,
				selector: "button[os-button], a[os-button]",
				inputs: [
					"variant",
					"size",
					"loading"
				]
			},
			{
				kind: "component",
				type: Dialog,
				selector: "dialog[os-dialog]",
				inputs: ["size"]
			},
			{
				kind: "directive",
				type: DialogBody,
				selector: "[os-dialog-body]"
			},
			{
				kind: "directive",
				type: DialogClose,
				selector: "button[os-dialog-close]",
				inputs: ["os-dialog-close"]
			},
			{
				kind: "directive",
				type: DialogFooter,
				selector: "[os-dialog-footer]"
			},
			{
				kind: "directive",
				type: DialogHeader,
				selector: "[os-dialog-header]"
			},
			{
				kind: "directive",
				type: DialogTitle,
				selector: "[os-dialog-title]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ConfirmDialogView,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-confirm-dialog",
			imports: [
				Button,
				Dialog,
				DialogBody,
				DialogClose,
				DialogFooter,
				DialogHeader,
				DialogTitle
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <dialog
      os-dialog
      size="sm"
      closedby="closerequest"
      [open]="true"
      [attr.aria-describedby]="messageId"
      (close)="onClose($event)"
    >
      <header os-dialog-header>
        <h2 os-dialog-title>{{ options().title }}</h2>
      </header>
      <div os-dialog-body>
        <p [id]="messageId">{{ options().message }}</p>
      </div>
      <footer os-dialog-footer>
        <button os-button os-dialog-close type="button" autofocus>
          {{ options().cancelLabel ?? 'Cancel' }}
        </button>
        <button
          os-button
          os-dialog-close="confirm"
          type="button"
          [variant]="options().danger ? 'danger' : 'primary'"
        >
          {{ options().confirmLabel }}
        </button>
      </footer>
    </dialog>
  `
		}]
	}],
	propDecorators: {
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		closed: [{
			type: i0.Output,
			args: ["closed"]
		}]
	}
});
var ConfirmDialog = class ConfirmDialog {
	app = inject(ApplicationRef);
	injector = inject(EnvironmentInjector);
	confirm(options) {
		const ref = createComponent(ConfirmDialogView, { environmentInjector: this.injector });
		ref.setInput("options", options);
		this.app.attachView(ref.hostView);
		document.body.append(ref.location.nativeElement);
		return new Promise((resolve) => {
			ref.instance.closed.subscribe((confirmed) => {
				resolve(confirmed);
				setTimeout(() => {
					ref.destroy();
				}, 250);
			});
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ConfirmDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ConfirmDialog,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ConfirmDialog,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var PopoverBase = class PopoverBase {
	placement = input("bottom", ...ngDevMode ? [{ debugName: "placement" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef).nativeElement;
	id = uniqueId("popover");
	isOpen = signal(false, ...ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []);
	show(source) {
		if (!this.element.matches(":popover-open")) this.element.showPopover({ source });
	}
	hide() {
		if (this.element.matches(":popover-open")) this.element.hidePopover();
	}
	onToggle(event) {
		this.isOpen.set(event.newState === "open");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PopoverBase,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PopoverBase,
		isStandalone: true,
		inputs: { placement: {
			classPropertyName: "placement",
			publicName: "placement",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "popover": "auto" },
			listeners: { "toggle": "onToggle($event)" },
			properties: {
				"id": "id",
				"attr.data-placement": "placement() === \"bottom\" ? null : placement()"
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PopoverBase,
	decorators: [{
		type: Directive,
		args: [{ host: {
			popover: "auto",
			"[id]": "id",
			"[attr.data-placement]": "placement() === \"bottom\" ? null : placement()",
			"(toggle)": "onToggle($event)"
		} }]
	}],
	propDecorators: { placement: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "placement",
			required: false
		}]
	}] }
});
var Popover = class Popover extends PopoverBase {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Popover,
		deps: null,
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: Popover,
		isStandalone: true,
		selector: "[os-popover]",
		host: { classAttribute: "os-popover" },
		providers: [{
			provide: PopoverBase,
			useExisting: Popover
		}],
		exportAs: ["osPopover"],
		usesInheritance: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Popover,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-popover]",
			exportAs: "osPopover",
			providers: [{
				provide: PopoverBase,
				useExisting: Popover
			}],
			host: { class: "os-popover" }
		}]
	}]
});
var PopoverTrigger = class PopoverTrigger {
	target = input.required({
		...ngDevMode ? { debugName: "target" } : /* istanbul ignore next */ {},
		alias: "os-popover-trigger"
	});
	constructor() {
		const trigger = inject(ElementRef).nativeElement;
		const destroyRef = inject(DestroyRef);
		afterNextRender(() => {
			destroyRef.onDestroy(anchor(trigger, this.target().element));
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PopoverTrigger,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PopoverTrigger,
		isStandalone: true,
		selector: "button[os-popover-trigger]",
		inputs: { target: {
			classPropertyName: "target",
			publicName: "os-popover-trigger",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { properties: {
			"attr.popovertarget": "target().id",
			"attr.aria-haspopup": "target().element.getAttribute(\"role\") === \"menu\" ? \"menu\" : null"
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PopoverTrigger,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[os-popover-trigger]",
			host: {
				"[attr.popovertarget]": "target().id",
				"[attr.aria-haspopup]": "target().element.getAttribute(\"role\") === \"menu\" ? \"menu\" : null"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { target: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "os-popover-trigger",
			required: true
		}]
	}] }
});
const ITEMS = ".os-menu-item:not(:disabled, [aria-disabled=\"true\"])";
var Menu = class Menu extends PopoverBase {
	onToggle(event) {
		super.onToggle(event);
		if (this.isOpen()) this.items()[0]?.focus();
	}
	onKeydown(event) {
		const items = this.items();
		const index = items.indexOf(document.activeElement);
		let next = {
			ArrowDown: (index + 1) % items.length,
			ArrowUp: (index - 1 + items.length) % items.length,
			Home: 0,
			End: items.length - 1
		}[event.key];
		if (next === void 0 && event.key.length === 1 && /\S/.test(event.key)) {
			const letter = event.key.toLowerCase();
			const match = [...items.slice(index + 1), ...items.slice(0, index + 1)].find((item) => item.textContent.trim().toLowerCase().startsWith(letter));
			next = match ? items.indexOf(match) : void 0;
		}
		if (next === void 0) {
			if (event.key === "Tab") this.hide();
			return;
		}
		event.preventDefault();
		items[next]?.focus();
	}
	onClick(event) {
		if (event.target.closest(ITEMS)) this.hide();
	}
	items() {
		return [...this.element.querySelectorAll(ITEMS)];
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Menu,
		deps: null,
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: Menu,
		isStandalone: true,
		selector: "[os-menu]",
		host: {
			attributes: { "role": "menu" },
			listeners: {
				"keydown": "onKeydown($event)",
				"click": "onClick($event)"
			},
			classAttribute: "os-menu"
		},
		providers: [{
			provide: PopoverBase,
			useExisting: Menu
		}],
		exportAs: ["osPopover"],
		usesInheritance: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Menu,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-menu]",
			exportAs: "osPopover",
			providers: [{
				provide: PopoverBase,
				useExisting: Menu
			}],
			host: {
				class: "os-menu",
				role: "menu",
				"(keydown)": "onKeydown($event)",
				"(click)": "onClick($event)"
			}
		}]
	}]
});
var MenuItem = class MenuItem {
	tone = input("default", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	isButton = inject(ElementRef).nativeElement.tagName === "BUTTON";
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MenuItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: MenuItem,
		isStandalone: true,
		selector: "button[os-menu-item], a[os-menu-item]",
		inputs: { tone: {
			classPropertyName: "tone",
			publicName: "tone",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: {
				"role": "menuitem",
				"tabindex": "-1"
			},
			properties: {
				"attr.type": "isButton ? \"button\" : null",
				"attr.data-tone": "tone() === \"danger\" ? \"danger\" : null"
			},
			classAttribute: "os-menu-item"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MenuItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[os-menu-item], a[os-menu-item]",
			host: {
				class: "os-menu-item",
				role: "menuitem",
				tabindex: "-1",
				"[attr.type]": "isButton ? \"button\" : null",
				"[attr.data-tone]": "tone() === \"danger\" ? \"danger\" : null"
			}
		}]
	}],
	propDecorators: { tone: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "tone",
			required: false
		}]
	}] }
});
var MenuSeparator = class MenuSeparator {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MenuSeparator,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: MenuSeparator,
		isStandalone: true,
		selector: "hr[os-menu-separator]",
		host: {
			attributes: { "role": "separator" },
			classAttribute: "os-menu-separator"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MenuSeparator,
	decorators: [{
		type: Directive,
		args: [{
			selector: "hr[os-menu-separator]",
			host: {
				class: "os-menu-separator",
				role: "separator"
			}
		}]
	}]
});
var MenuLabel = class MenuLabel {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MenuLabel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: MenuLabel,
		isStandalone: true,
		selector: "[os-menu-label]",
		host: {
			attributes: { "role": "presentation" },
			classAttribute: "os-menu-label"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MenuLabel,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-menu-label]",
			host: {
				class: "os-menu-label",
				role: "presentation"
			}
		}]
	}]
});
var Tooltip = class Tooltip {
	text = input.required({
		...ngDevMode ? { debugName: "text" } : /* istanbul ignore next */ {},
		alias: "os-tooltip"
	});
	placement = input("top", ...ngDevMode ? [{ debugName: "placement" }] : /* istanbul ignore next */ []);
	id = uniqueId("tooltip");
	host = inject(ElementRef).nativeElement;
	tip = document.createElement("div");
	constructor() {
		this.tip.id = this.id;
		this.tip.className = "os-tooltip";
		this.tip.setAttribute("popover", "hint");
		effect(() => {
			this.tip.textContent = this.text();
			const placement = this.placement();
			if (placement === "top") delete this.tip.dataset["placement"];
			else this.tip.dataset["placement"] = placement;
		});
		const destroyRef = inject(DestroyRef);
		afterNextRender(() => {
			document.body.append(this.tip);
			const undo = anchor(this.host, this.tip);
			destroyRef.onDestroy(() => {
				undo();
				this.tip.remove();
			});
		});
	}
	describes() {
		return this.text().trim() !== this.host.getAttribute("aria-label")?.trim();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Tooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Tooltip,
		isStandalone: true,
		selector: "[os-tooltip]",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "os-tooltip",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			placement: {
				classPropertyName: "placement",
				publicName: "placement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: {
			"attr.interestfor": "id",
			"attr.aria-describedby": "describes() ? id : null"
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Tooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-tooltip]",
			host: {
				"[attr.interestfor]": "id",
				"[attr.aria-describedby]": "describes() ? id : null"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "os-tooltip",
				required: true
			}]
		}],
		placement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placement",
				required: false
			}]
		}]
	}
});
var ToastRegion = class ToastRegion {
	toasts = signal([], ...ngDevMode ? [{ debugName: "toasts" }] : /* istanbul ignore next */ []);
	iconX = iconX;
	timers = /* @__PURE__ */ new Map();
	region = inject(ElementRef).nativeElement;
	constructor() {
		const region = this.region;
		effect(() => {
			const open = region.matches(":popover-open");
			if (this.toasts().length && !open) region.showPopover();
			if (!this.toasts().length && open) region.hidePopover();
		});
	}
	add(toast) {
		if (this.region.matches(":popover-open")) {
			this.region.hidePopover();
			this.region.showPopover();
		}
		this.toasts.update((list) => [...list, toast]);
		this.resume(toast);
	}
	dismiss(id) {
		clearTimeout(this.timers.get(id));
		this.timers.delete(id);
		this.toasts.update((list) => list.filter((toast) => toast.id !== id));
	}
	pause(toast) {
		clearTimeout(this.timers.get(toast.id));
	}
	resume(toast) {
		const duration = toast.duration ?? (toast.action ? 1e4 : 5e3);
		if (duration > 0) this.timers.set(toast.id, setTimeout(() => {
			this.dismiss(toast.id);
		}, duration));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ToastRegion,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ToastRegion,
		isStandalone: true,
		selector: "os-toast-region",
		host: {
			attributes: { "popover": "manual" },
			classAttribute: "os-toast-region"
		},
		ngImport: i0,
		template: `
    @for (toast of toasts(); track toast.id) {
      <div
        class="os-toast"
        [attr.data-tone]="toast.tone ?? 'neutral'"
        [attr.role]="toast.tone === 'danger' ? 'alert' : 'status'"
        (pointerenter)="pause(toast)"
        (pointerleave)="resume(toast)"
      >
        <p class="os-toast-message">{{ toast.message }}</p>
        @if (toast.action; as action) {
          <button os-button type="button" size="sm" (click)="action.run(); dismiss(toast.id)">
            {{ action.label }}
          </button>
        }
        <button
          os-icon-button
          type="button"
          variant="ghost"
          size="sm"
          label="Close"
          (click)="dismiss(toast.id)"
        >
          <svg os-icon [icon]="iconX"></svg>
        </button>
      </div>
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Button,
				selector: "button[os-button], a[os-button]",
				inputs: [
					"variant",
					"size",
					"loading"
				]
			},
			{
				kind: "component",
				type: IconButton,
				selector: "button[os-icon-button], a[os-icon-button]",
				inputs: ["label"]
			},
			{
				kind: "directive",
				type: Icon,
				selector: "svg[os-icon]",
				inputs: [
					"icon",
					"size",
					"flipInRtl"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ToastRegion,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-toast-region",
			imports: [
				Button,
				IconButton,
				Icon
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "os-toast-region",
				popover: "manual"
			},
			template: `
    @for (toast of toasts(); track toast.id) {
      <div
        class="os-toast"
        [attr.data-tone]="toast.tone ?? 'neutral'"
        [attr.role]="toast.tone === 'danger' ? 'alert' : 'status'"
        (pointerenter)="pause(toast)"
        (pointerleave)="resume(toast)"
      >
        <p class="os-toast-message">{{ toast.message }}</p>
        @if (toast.action; as action) {
          <button os-button type="button" size="sm" (click)="action.run(); dismiss(toast.id)">
            {{ action.label }}
          </button>
        }
        <button
          os-icon-button
          type="button"
          variant="ghost"
          size="sm"
          label="Close"
          (click)="dismiss(toast.id)"
        >
          <svg os-icon [icon]="iconX"></svg>
        </button>
      </div>
    }
  `
		}]
	}],
	ctorParameters: () => []
});
var Toaster = class Toaster {
	app = inject(ApplicationRef);
	injector = inject(EnvironmentInjector);
	region;
	next = 0;
	show(message, options = {}) {
		const id = this.next++;
		this.getRegion().add({
			...options,
			id,
			message
		});
		return () => {
			this.region?.dismiss(id);
		};
	}
	getRegion() {
		if (!this.region) {
			const ref = createComponent(ToastRegion, { environmentInjector: this.injector });
			this.app.attachView(ref.hostView);
			document.body.append(ref.location.nativeElement);
			this.region = ref.instance;
		}
		return this.region;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Toaster,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Toaster,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Toaster,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var Cell = class Cell {
	key = input.required({
		...ngDevMode ? { debugName: "key" } : /* istanbul ignore next */ {},
		alias: "os-cell"
	});
	template = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Cell,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Cell,
		isStandalone: true,
		selector: "ng-template[os-cell]",
		inputs: { key: {
			classPropertyName: "key",
			publicName: "os-cell",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Cell,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[os-cell]" }]
	}],
	propDecorators: { key: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "os-cell",
			required: true
		}]
	}] }
});
var DataTable = class DataTable {
	caption = input.required(...ngDevMode ? [{ debugName: "caption" }] : /* istanbul ignore next */ []);
	columns = input.required(...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	rows = input.required(...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	rowKey = input(...ngDevMode ? [void 0, { debugName: "rowKey" }] : /* istanbul ignore next */ []);
	empty = input("Nothing here yet.", ...ngDevMode ? [{ debugName: "empty" }] : /* istanbul ignore next */ []);
	cellTemplates = contentChildren(Cell, ...ngDevMode ? [{ debugName: "cellTemplates" }] : /* istanbul ignore next */ []);
	cells = computed(() => Object.fromEntries(this.cellTemplates().map((cell) => [cell.key(), cell.template])), ...ngDevMode ? [{ debugName: "cells" }] : /* istanbul ignore next */ []);
	rowId(row, index) {
		const key = this.rowKey();
		return key === void 0 ? index : row[key];
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DataTable,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: DataTable,
		isStandalone: true,
		selector: "os-data-table",
		inputs: {
			caption: {
				classPropertyName: "caption",
				publicName: "caption",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			rowKey: {
				classPropertyName: "rowKey",
				publicName: "rowKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			empty: {
				classPropertyName: "empty",
				publicName: "empty",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "os-data-table" },
		queries: [{
			propertyName: "cellTemplates",
			predicate: Cell,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <table role="table">
      <caption class="os-visually-hidden">
        {{
          caption()
        }}
      </caption>
      <thead role="rowgroup">
        <tr role="row">
          @for (column of columns(); track column.key) {
            <th role="columnheader" scope="col" [attr.data-align]="column.align ?? null">
              {{ column.label }}
            </th>
          }
        </tr>
      </thead>
      <tbody role="rowgroup">
        @for (row of rows(); track rowId(row, $index)) {
          <tr role="row">
            @for (column of columns(); track column.key) {
              <td
                role="cell"
                [attr.data-label]="column.label"
                [attr.data-align]="column.align ?? null"
              >
                @if (cells()[column.key]; as cell) {
                  <ng-container
                    [ngTemplateOutlet]="cell"
                    [ngTemplateOutletContext]="{ $implicit: row }"
                  />
                } @else {
                  {{ row[column.key] }}
                }
              </td>
            }
          </tr>
        } @empty {
          <tr role="row">
            <td role="cell" class="os-data-table-empty" [attr.colspan]="columns().length">
              {{ empty() }}
            </td>
          </tr>
        }
      </tbody>
    </table>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DataTable,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-data-table",
			imports: [NgTemplateOutlet],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "os-data-table" },
			template: `
    <table role="table">
      <caption class="os-visually-hidden">
        {{
          caption()
        }}
      </caption>
      <thead role="rowgroup">
        <tr role="row">
          @for (column of columns(); track column.key) {
            <th role="columnheader" scope="col" [attr.data-align]="column.align ?? null">
              {{ column.label }}
            </th>
          }
        </tr>
      </thead>
      <tbody role="rowgroup">
        @for (row of rows(); track rowId(row, $index)) {
          <tr role="row">
            @for (column of columns(); track column.key) {
              <td
                role="cell"
                [attr.data-label]="column.label"
                [attr.data-align]="column.align ?? null"
              >
                @if (cells()[column.key]; as cell) {
                  <ng-container
                    [ngTemplateOutlet]="cell"
                    [ngTemplateOutletContext]="{ $implicit: row }"
                  />
                } @else {
                  {{ row[column.key] }}
                }
              </td>
            }
          </tr>
        } @empty {
          <tr role="row">
            <td role="cell" class="os-data-table-empty" [attr.colspan]="columns().length">
              {{ empty() }}
            </td>
          </tr>
        }
      </tbody>
    </table>
  `
		}]
	}],
	propDecorators: {
		caption: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "caption",
				required: true
			}]
		}],
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: true
			}]
		}],
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: true
			}]
		}],
		rowKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowKey",
				required: false
			}]
		}],
		empty: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "empty",
				required: false
			}]
		}],
		cellTemplates: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => Cell), { isSignal: true }]
		}]
	}
});
var StatTile = class StatTile {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	value = input.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	hint = input(...ngDevMode ? [void 0, { debugName: "hint" }] : /* istanbul ignore next */ []);
	tone = input("neutral", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StatTile,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: StatTile,
		isStandalone: true,
		selector: "os-stat-tile",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "os-stat-tile" },
		ngImport: i0,
		template: `
    <span class="os-stat-label">{{ label() }}</span>
    <span class="os-stat-value">{{ value() }}</span>
    @if (hint()) {
      <span class="os-stat-hint" [attr.data-tone]="tone()">{{ hint() }}</span>
    }
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StatTile,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-stat-tile",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "os-stat-tile" },
			template: `
    <span class="os-stat-label">{{ label() }}</span>
    <span class="os-stat-value">{{ value() }}</span>
    @if (hint()) {
      <span class="os-stat-hint" [attr.data-tone]="tone()">{{ hint() }}</span>
    }
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}],
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}]
	}
});
var StatGrid = class StatGrid {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StatGrid,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: StatGrid,
		isStandalone: true,
		selector: "[os-stat-grid]",
		host: { classAttribute: "os-stat-grid" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StatGrid,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-stat-grid]",
			host: { class: "os-stat-grid" }
		}]
	}]
});
var Page = class Page {
	width = input("default", ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Page,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Page,
		isStandalone: true,
		selector: "[os-page]",
		inputs: { width: {
			classPropertyName: "width",
			publicName: "width",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: { "attr.data-width": "width() === \"default\" ? null : width()" },
			classAttribute: "os-page"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Page,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-page]",
			host: {
				class: "os-page",
				"[attr.data-width]": "width() === \"default\" ? null : width()"
			}
		}]
	}],
	propDecorators: { width: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "width",
			required: false
		}]
	}] }
});
var PageHeader = class PageHeader {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	description = input(...ngDevMode ? [void 0, { debugName: "description" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PageHeader,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: PageHeader,
		isStandalone: true,
		selector: "header[os-page-header]",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "os-page-header" },
		ngImport: i0,
		template: `
    <div>
      <h1 class="os-page-title">{{ title() }}</h1>
      @if (description()) {
        <p class="os-page-description">{{ description() }}</p>
      }
    </div>
    <div class="os-page-actions"><ng-content /></div>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PageHeader,
	decorators: [{
		type: Component,
		args: [{
			selector: "header[os-page-header]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "os-page-header" },
			template: `
    <div>
      <h1 class="os-page-title">{{ title() }}</h1>
      @if (description()) {
        <p class="os-page-description">{{ description() }}</p>
      }
    </div>
    <div class="os-page-actions"><ng-content /></div>
  `
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}]
	}
});
var Breadcrumbs = class Breadcrumbs {
	label = input("Breadcrumbs", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Breadcrumbs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Breadcrumbs,
		isStandalone: true,
		selector: "nav[os-breadcrumbs]",
		inputs: { label: {
			classPropertyName: "label",
			publicName: "label",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: { "attr.aria-label": "label()" },
			classAttribute: "os-breadcrumbs"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Breadcrumbs,
	decorators: [{
		type: Directive,
		args: [{
			selector: "nav[os-breadcrumbs]",
			host: {
				class: "os-breadcrumbs",
				"[attr.aria-label]": "label()"
			}
		}]
	}],
	propDecorators: { label: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "label",
			required: false
		}]
	}] }
});
var Panel = class Panel {
	title = input(...ngDevMode ? [void 0, { debugName: "title" }] : /* istanbul ignore next */ []);
	description = input(...ngDevMode ? [void 0, { debugName: "description" }] : /* istanbul ignore next */ []);
	level = input(2, {
		...ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	flush = input(false, {
		...ngDevMode ? { debugName: "flush" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	titleId = uniqueId("panel-title");
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Panel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: Panel,
		isStandalone: true,
		selector: "[os-panel]",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			level: {
				classPropertyName: "level",
				publicName: "level",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flush: {
				classPropertyName: "flush",
				publicName: "flush",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: { "attr.aria-labelledby": "title() ? titleId : null" },
			classAttribute: "os-panel"
		},
		ngImport: i0,
		template: `
    @if (title()) {
      <header class="os-panel-header">
        <div>
          <h2 role="heading" [attr.aria-level]="level()" [id]="titleId">{{ title() }}</h2>
          @if (description()) {
            <p>{{ description() }}</p>
          }
        </div>
        <ng-content select="[os-actions]" />
      </header>
    }
    <div class="os-panel-body" [attr.data-flush]="flush() ? '' : null"><ng-content /></div>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Panel,
	decorators: [{
		type: Component,
		args: [{
			selector: "[os-panel]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "os-panel",
				"[attr.aria-labelledby]": "title() ? titleId : null"
			},
			template: `
    @if (title()) {
      <header class="os-panel-header">
        <div>
          <h2 role="heading" [attr.aria-level]="level()" [id]="titleId">{{ title() }}</h2>
          @if (description()) {
            <p>{{ description() }}</p>
          }
        </div>
        <ng-content select="[os-actions]" />
      </header>
    }
    <div class="os-panel-body" [attr.data-flush]="flush() ? '' : null"><ng-content /></div>
  `
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}],
		level: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "level",
				required: false
			}]
		}],
		flush: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flush",
				required: false
			}]
		}]
	}
});
var Card = class Card {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Card,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: Card,
		isStandalone: true,
		selector: "[os-card]",
		host: { classAttribute: "os-card" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Card,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-card]",
			host: { class: "os-card" }
		}]
	}]
});
var CardGrid = class CardGrid {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CardGrid,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: CardGrid,
		isStandalone: true,
		selector: "[os-card-grid]",
		host: { classAttribute: "os-card-grid" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CardGrid,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-card-grid]",
			host: { class: "os-card-grid" }
		}]
	}]
});
var Tab = class Tab {
	value = input.required({
		...ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {},
		alias: "os-tab"
	});
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	template = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Tab,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Tab,
		isStandalone: true,
		selector: "ng-template[os-tab]",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "os-tab",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Tab,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[os-tab]" }]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "os-tab",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}]
	}
});
var Tabs = class Tabs {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	selected = model(...ngDevMode ? [void 0, { debugName: "selected" }] : /* istanbul ignore next */ []);
	tabs = contentChildren(Tab, ...ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			if (this.selected() === void 0) this.selected.set(this.tabs().find((tab) => !tab.disabled())?.value());
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Tabs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: Tabs,
		isStandalone: true,
		selector: "os-tabs",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { selected: "selectedChange" },
		host: { classAttribute: "os-tabs" },
		queries: [{
			propertyName: "tabs",
			predicate: Tab,
			isSignal: true
		}],
		hostDirectives: [{ directive: i1.Tabs }],
		ngImport: i0,
		template: `
    <div
      ngTabList
      class="os-tab-list"
      selectionMode="follow"
      [softDisabled]="false"
      [attr.aria-label]="label()"
      [(selectedTab)]="selected"
    >
      @for (tab of tabs(); track tab.value()) {
        <button
          ngTab
          class="os-tab"
          type="button"
          [value]="tab.value()"
          [disabled]="tab.disabled()"
        >
          {{ tab.label() }}
        </button>
      }
    </div>
    @for (tab of tabs(); track tab.value()) {
      <div ngTabPanel class="os-tab-panel" [value]="tab.value()">
        <ng-template ngTabContent>
          <ng-container [ngTemplateOutlet]="tab.template" />
        </ng-template>
      </div>
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: Tab$1,
				selector: "[ngTab]",
				inputs: [
					"id",
					"disabled",
					"value"
				],
				exportAs: ["ngTab"]
			},
			{
				kind: "directive",
				type: TabContent,
				selector: "ng-template[ngTabContent]",
				exportAs: ["ngTabContent"]
			},
			{
				kind: "directive",
				type: TabList,
				selector: "[ngTabList]",
				inputs: [
					"orientation",
					"wrap",
					"softDisabled",
					"focusMode",
					"selectionMode",
					"selectedTab",
					"disabled"
				],
				outputs: ["selectedTabChange"],
				exportAs: ["ngTabList"]
			},
			{
				kind: "directive",
				type: TabPanel,
				selector: "[ngTabPanel]",
				inputs: ["id", "value"],
				exportAs: ["ngTabPanel"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Tabs,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-tabs",
			imports: [
				Tab$1,
				TabContent,
				TabList,
				TabPanel,
				NgTemplateOutlet
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "os-tabs" },
			hostDirectives: [Tabs$1],
			template: `
    <div
      ngTabList
      class="os-tab-list"
      selectionMode="follow"
      [softDisabled]="false"
      [attr.aria-label]="label()"
      [(selectedTab)]="selected"
    >
      @for (tab of tabs(); track tab.value()) {
        <button
          ngTab
          class="os-tab"
          type="button"
          [value]="tab.value()"
          [disabled]="tab.disabled()"
        >
          {{ tab.label() }}
        </button>
      }
    </div>
    @for (tab of tabs(); track tab.value()) {
      <div ngTabPanel class="os-tab-panel" [value]="tab.value()">
        <ng-template ngTabContent>
          <ng-container [ngTemplateOutlet]="tab.template" />
        </ng-template>
      </div>
    }
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectedChange"]
		}],
		tabs: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => Tab), { isSignal: true }]
		}]
	}
});
var SettingCard = class SettingCard {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	description = input(...ngDevMode ? [void 0, { debugName: "description" }] : /* istanbul ignore next */ []);
	level = input(2, {
		...ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	tone = input("neutral", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	titleId = uniqueId("setting-card");
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SettingCard,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: SettingCard,
		isStandalone: true,
		selector: "[os-setting-card]",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			level: {
				classPropertyName: "level",
				publicName: "level",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-tone": "tone() === \"danger\" ? \"danger\" : null",
				"attr.aria-labelledby": "titleId"
			},
			classAttribute: "os-setting-card"
		},
		ngImport: i0,
		template: `
    <header class="os-setting-card-header">
      <h2 [attr.aria-level]="level()" [id]="titleId">{{ title() }}</h2>
      @if (description()) {
        <p>{{ description() }}</p>
      }
    </header>
    <ng-content />
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SettingCard,
	decorators: [{
		type: Component,
		args: [{
			selector: "[os-setting-card]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "os-setting-card",
				"[attr.data-tone]": "tone() === \"danger\" ? \"danger\" : null",
				"[attr.aria-labelledby]": "titleId"
			},
			template: `
    <header class="os-setting-card-header">
      <h2 [attr.aria-level]="level()" [id]="titleId">{{ title() }}</h2>
      @if (description()) {
        <p>{{ description() }}</p>
      }
    </header>
    <ng-content />
  `
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}],
		level: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "level",
				required: false
			}]
		}],
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}]
	}
});
var SettingCardFooter = class SettingCardFooter {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SettingCardFooter,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: SettingCardFooter,
		isStandalone: true,
		selector: "[os-setting-card-footer]",
		host: { classAttribute: "os-setting-card-footer" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SettingCardFooter,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-setting-card-footer]",
			host: { class: "os-setting-card-footer" }
		}]
	}]
});
var SettingRow = class SettingRow {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	description = input(...ngDevMode ? [void 0, { debugName: "description" }] : /* istanbul ignore next */ []);
	inline = input(false, {
		...ngDevMode ? { debugName: "inline" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	controlId = uniqueId("setting");
	descriptionId = uniqueId("setting-description");
	describedBy = computed(() => this.description() ? this.descriptionId : null, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	invalid = computed(() => false, ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SettingRow,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: SettingRow,
		isStandalone: true,
		selector: "os-setting-row",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inline: {
				classPropertyName: "inline",
				publicName: "inline",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: { "attr.data-inline": "inline() ? \"\" : null" },
			classAttribute: "os-setting-row"
		},
		providers: [{
			provide: FIELD,
			useExisting: SettingRow
		}],
		ngImport: i0,
		template: `
    <div class="os-setting-text">
      <label [for]="controlId">{{ label() }}</label>
      @if (description()) {
        <p [id]="descriptionId">{{ description() }}</p>
      }
    </div>
    <div class="os-setting-control"><ng-content /></div>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SettingRow,
	decorators: [{
		type: Component,
		args: [{
			selector: "os-setting-row",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: FIELD,
				useExisting: SettingRow
			}],
			host: {
				class: "os-setting-row",
				"[attr.data-inline]": "inline() ? \"\" : null"
			},
			template: `
    <div class="os-setting-text">
      <label [for]="controlId">{{ label() }}</label>
      @if (description()) {
        <p [id]="descriptionId">{{ description() }}</p>
      }
    </div>
    <div class="os-setting-control"><ng-content /></div>
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}],
		inline: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inline",
				required: false
			}]
		}]
	}
});
var FormActions = class FormActions {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormActions,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FormActions,
		isStandalone: true,
		selector: "[os-form-actions]",
		host: { classAttribute: "os-form-actions" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormActions,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-form-actions]",
			host: { class: "os-form-actions" }
		}]
	}]
});
var FormActionsNote = class FormActionsNote {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormActionsNote,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FormActionsNote,
		isStandalone: true,
		selector: "[os-form-actions-note]",
		host: { classAttribute: "os-form-actions-note" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormActionsNote,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[os-form-actions-note]",
			host: { class: "os-form-actions-note" }
		}]
	}]
});
export { Badge, Breadcrumbs, Button, Callout, Card, CardGrid, Cell, Check, Checkbox, Chip, CommandPalette, ConfirmDialog, Control, DataTable, Dialog, DialogBase, DialogBody, DialogClose, DialogFooter, DialogHeader, DialogTitle, Drawer, EmptyState, FIELD, Field, Fieldset, FormActions, FormActionsNote, Icon, IconButton, Kbd, Menu, MenuItem, MenuLabel, MenuSeparator, Page, PageHeader, Panel, Popover, PopoverBase, PopoverTrigger, Radio, SegmentedControl, SettingCard, SettingCardFooter, SettingRow, Skeleton, StatGrid, StatTile, StatusDot, Switch, Tab, Tabs, Toaster, Tooltip, matchesQuery };

//# sourceMappingURL=openstuff-dev-ui-angular.mjs.map